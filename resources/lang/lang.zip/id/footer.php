<?php

return [
    'kantor'   => 'Kantor Perusahaan',
    'service'   => 'Fokus Layanan',
    'iklan' => 'Masih belum puas dengan informasi yang didapat? atau langsung ingin berkonsultasi tentang proyek Anda?',
    'usnow' => 'Hubungi Kami Sekarang!',
    'working' => 'Jam Kerja Kantor',
    'hari' => 'Senin - Jum`at',
    'hari2' => 'Sabtu',
    'jalan' => 'Alamat Kantor Perusahaan',
    'carian' => 'Cari artikel berdasarkan kata kunci...',
];