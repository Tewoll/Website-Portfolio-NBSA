<?php

return [
    'all'    => 'Semua',
    'result' => 'hasil',
    'selesai' => 'Proyek Selesai',
    'overview' => 'Ringkasan',
    'durasi' => 'Durasi Proyek (Bulan)',
    'mulai' => 'Proyek Mulai',
    'end' => 'Proyek Selesai',
    'bulan' => 'Bulan',
    'publish' => 'Diterbitkan',
    'recent' => 'Portofolio Baru Ditambahkan',
    'view' => 'Lihat semua',
    'bagi' => 'Bagikan',
];