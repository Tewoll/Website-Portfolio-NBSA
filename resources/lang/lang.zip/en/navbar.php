<?php

return [
    'home'    => 'Home',
    'about'   => 'About Us',
    'contact' => 'Contact Us',
    'proyek' => 'Our Project',
    'news' => 'NBSA News',
    'privacy' => 'Privacy Policy',
    'port' => 'Project Portfolio',
    
];