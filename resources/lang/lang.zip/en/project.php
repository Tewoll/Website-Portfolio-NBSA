<?php

return [
    'all'    => 'All',
    'result' => 'results',
    'selesai' => 'Completed',
    'overview' => 'Overview',
    'durasi' => 'Project Duration (Months)',
    'mulai' => 'Project Start',
    'end' => 'Project End',
    'bulan' => 'Month',
    'publish' => 'Published',
    'recent' => 'Recently Portfolio Added',
    'view' => 'View all',
    'bagi' => 'Share',

];