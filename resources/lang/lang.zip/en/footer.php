<?php

return [
    'kantor'   => 'Corporate Office',
    'service'   => 'Service Focus',
    'iklan' => 'Still not satisfied with the information obtained? or directly want to consult about your project?',
    'usnow' => 'Contact Us now!',
    'working' => 'Working Hours',
    'hari' => 'Monday - Friday',
    'hari2' => 'Saturday',
    'jalan' => 'Corporate Office Address',
    'carian' => 'Search articles by keywords...',
];