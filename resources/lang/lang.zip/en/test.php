<?php
return [
	'welcome' => 'Welcome to our website.',
	"title" => "Please fill form below correctly.",
	"profil" => [
		"name" => "Your Name",
		"address" => "Your Address",
		"hobby" => "Your Hobby",
		"job" => "Your Job",
	],
	"button" => "Save",
	"thank" => "Thank you for your contribution.",
];