<?php

return [
    'home'    => 'Beranda',
    'about'   => 'Tentang Kami',
    'contact' => 'Kontak',
    'proyek' => 'Project Portfolio',
    'news' => 'NBSA News',
    'privacy' => 'Kebijakan Privasi',
    'port' => 'Portfolio Proyek',
];