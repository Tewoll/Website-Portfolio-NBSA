<?php

namespace App\Http\Controllers;

use App\Models\DetailArtikel;
use Illuminate\Http\Request;

class DetailArtikelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\DetailArtikel  $detailArtikel
     * @return \Illuminate\Http\Response
     */
    public function show(DetailArtikel $detailArtikel)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\DetailArtikel  $detailArtikel
     * @return \Illuminate\Http\Response
     */
    public function edit(DetailArtikel $detailArtikel)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\DetailArtikel  $detailArtikel
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DetailArtikel $detailArtikel)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\DetailArtikel  $detailArtikel
     * @return \Illuminate\Http\Response
     */
    public function destroy(DetailArtikel $detailArtikel)
    {
        //
    }
}
